// ================================================================================
// Name         : 
// Author       : Dallas Hansen
// Course       : CIS 127 - 5541.W24
// Date         : 
// Description  : 
// ================================================================================

#include <iostream>
using namespace std;

int main() {
	// code
	return 0;
}